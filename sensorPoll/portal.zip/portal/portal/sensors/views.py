from django.http import HttpResponse
from django.shortcuts import render_to_response
from urllib2 import URLError, urlopen
from settings import SENSORDATA_URL

def table(request):
	return HttpResponse(readURL(SENSORDATA_URL + "?type=current"))

def minutegraph(request):
	return buffer(request,SENSORDATA_URL,'m')

def hourgraph(request):
	return buffer(request,(SENSORDATA_URL + "?type=hour"), 'h');


def readURL(url):
	try:
		remote = urlopen(url)
		value = remote.read()
		remote.close()
	except URLError, e:
		value = "Unavailable"
	
	return value;

def buffer(request,url,code):
	a = lambda : readURL(url)
	_frontbuf = 0
	_backbuf = 1

	_buf = [
                request.session.get(code +'buf0', a()),
                request.session.get(code +'buf1', a())
                ]

	_buf[_frontbuf] = _buf[_backbuf]	
	_buf[_backbuf] = a()

	request.session[code +'buf0'] = _buf[_frontbuf]
	request.session[code +'buf1'] = _buf[_backbuf]

	return render_to_response('sensors/chart.html', {'buf0_url': _buf[0], 'buf1_url': _buf[1]})
