from django.http import HttpResponse
from django.shortcuts import render_to_response
from urllib2 import URLError, urlopen
from settings import SENSORDATA_URL

def table(request):
	return HttpResponse(readURL(SENSORDATA_URL + "?type=current"))

def minutegraph(request):
	return buffer(request,SENSORDATA_URL)

def hourgraph(request):
	return buffer(request,(SENSORDATA_URL + "?type=hour"));


def readURL(url):
	try:
		remote = urlopen(url)
		value = remote.read()
		remote.close()
	except URLError, e:
		value = "Unavailable"
	
	return value;

def buffer(request,url):
	a = lambda : readURL(url)
	_frontbuf = 0
	_backbuf = 1

	_buf = [
                request.session.get('buf0', a()),
                request.session.get('buf1', a())
                ]

	_buf[_frontbuf] = _buf[_backbuf]	
	_buf[_backbuf] = a()

	request.session['buf0'] = _buf[_frontbuf]
	request.session['buf1'] = _buf[_backbuf]

	return render_to_response('sensors/chart.html', {'buf0_url': _buf[0], 'buf1_url': _buf[1]})
