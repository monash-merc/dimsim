from django.conf.urls.defaults import *

urlpatterns = patterns('',
    #Note that the names are used in /templates/portal.html
    url(r'^ming$', 'portal.portal.sensors.views.minutegraph', name='ming'),
    url(r'^hourg$', 'portal.portal.sensors.views.hourgraph', name='hourg'),
    url(r'^curr$', 'portal.portal.sensors.views.table', name='sensors_curr'),
)
